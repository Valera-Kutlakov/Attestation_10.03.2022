﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CollegeClassLib;

namespace CollegeClassLibTest
{
    class Program
    {
        static void Main(string[] args)
        {
            CollegeClass college = new CollegeClass();

            string[] marksAVG = new string[] { "1", "2", "4", "2", "5", "5", "4", "3", "5", "1" };

            List<CollegeClass.Mark> marks = new List<CollegeClass.Mark> { new CollegeClass.Mark(Convert.ToDateTime("01.01.2022"), "Прогул"),
                                                                          new CollegeClass.Mark(Convert.ToDateTime("02.01.2022"), "Прогул"), 
                                                                          new CollegeClass.Mark(Convert.ToDateTime("03.01.2022"), "Болезнь"),
                                                                          new CollegeClass.Mark(Convert.ToDateTime("04.01.2022"), "2"), 
                                                                          new CollegeClass.Mark(Convert.ToDateTime("05.01.2022"), "5"),
                                                                          new CollegeClass.Mark(Convert.ToDateTime("06.01.2022"), "Прогул"), 
                                                                          new CollegeClass.Mark(Convert.ToDateTime("07.02.2022"), "Болезнь"),
                                                                          new CollegeClass.Mark(Convert.ToDateTime("02.02.2022"), "3"), 
                                                                          new CollegeClass.Mark(Convert.ToDateTime("01.02.2022"), "Прогул"),
                                                                          new CollegeClass.Mark(Convert.ToDateTime("02.02.2022"), "Болезнь")};

            List<CollegeClass.Student> students = new List<CollegeClass.Student> { new CollegeClass.Student(2000, 101, "Иванов Пётр Семёнович"),
                                                                                   new CollegeClass.Student(2001, 202, "Павлов Даниил Анатольевич"),
                                                                                   new CollegeClass.Student(2002, 303, "Еремина Ярослава Георгиевна"),
                                                                                   new CollegeClass.Student(2003, 404, "Ершова Варвара Дмитриевна"),
                                                                                   new CollegeClass.Student(2004, 505, "Буров Степан Михайлович"),
                                                                                   new CollegeClass.Student(2005, 606, "Осипов Олег Львович")};

            // Вычисление среднего арифметического значения оценки в меньшую сторону
            Console.WriteLine(college.MinAVG(marksAVG));
            Console.WriteLine();

            // Вычисление количество прогулов за месяц за период
            for (int i = 0; i < college.GetCountTruancy(marks).Length; i++)
            {
                Console.WriteLine(college.GetCountTruancy(marks)[i]);
            }
            Console.WriteLine();

            // Вычисление количество пропусков по болезни за месяц за период
            for (int i = 0; i < college.GetCountDisease(marks).Length; i++)
            {
                Console.WriteLine(college.GetCountDisease(marks)[i]);
            }
            Console.WriteLine();

            // Генерация номера студенческого билета
            Console.WriteLine(college.GetStudNumber(students[0]));
            Console.WriteLine(college.GetStudNumber(students[1]));
            Console.WriteLine(college.GetStudNumber(students[2]));
            Console.WriteLine(college.GetStudNumber(students[3]));
            Console.WriteLine(college.GetStudNumber(students[4]));
            Console.WriteLine(college.GetStudNumber(students[5]));
            Console.WriteLine();

            // Генерация оценок на 10 дней вперед, начиная с текущей даты со списком переданных студентов
            List<CollegeClass.Mark> marksRandom = college.GetMarks(DateTime.Today, students);
            for (int i = 0; i < marksRandom.Count; i++)
            {
                Console.WriteLine(marksRandom[i].date + ": " + marksRandom[i].estimation);
            }
            Console.ReadKey();
        }
    }
}
