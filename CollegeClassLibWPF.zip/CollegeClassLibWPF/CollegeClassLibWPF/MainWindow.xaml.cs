﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using CollegeClassLib;

namespace CollegeClassLibWPF
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            CollegeClass college = new CollegeClass();

            List<CollegeClass.Student> students = new List<CollegeClass.Student> { new CollegeClass.Student(2000, 101, "Иванов Пётр Семёнович"),
                                                                                   new CollegeClass.Student(2001, 202, "Павлов Даниил Анатольевич"),
                                                                                   new CollegeClass.Student(2002, 303, "Еремина Ярослава Георгиевна"),
                                                                                   new CollegeClass.Student(2003, 404, "Ершова Варвара Дмитриевна"),
                                                                                   new CollegeClass.Student(2004, 505, "Буров Степан Михайлович"),
                                                                                   new CollegeClass.Student(2005, 606, "Осипов Олег Львович")};
            List<string> studNumber = new List<string> { college.GetStudNumber(students[0]), college.GetStudNumber(students[1]),
                                                         college.GetStudNumber(students[2]), college.GetStudNumber(students[3]),
                                                         college.GetStudNumber(students[4]), college.GetStudNumber(students[5])};
            List<CollegeClass.Mark> marks = college.GetMarks(Convert.ToDateTime("26.03.2022"), students);
            List<string> marksAVG = new List<string> { };
            for (int i = 0; i < marks.Count; i++)
            {
                marksAVG.Add(marks[i].estimation);
            }
            dgStudent.ItemsSource = students;
            dgStudNumber.ItemsSource = studNumber;
            dgMarks.ItemsSource = marks;
            lblTruancyFirst.Content = college.GetCountTruancy(marks)[0].ToString();
            lblDiseaseFirst.Content = college.GetCountDisease(marks)[0].ToString();
            if (college.GetCountTruancy(marks).Length == 2)
            {
                lblTruancySecond.Content = college.GetCountTruancy(marks)[1].ToString();
                lblDiseaseSecond.Content = college.GetCountDisease(marks)[1].ToString();
            }
            lblMarksAVG.Content = college.MinAVG(marksAVG.ToArray()).ToString();
        }
    }
}
