﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CollegeClassLib
{
    public class CollegeClass
    {
        public class Mark
        {
            public DateTime date { get; set; }
            public string estimation { get; set; }
            public Mark()
            {
                date = DateTime.Now;
                estimation = "";
            }
            public Mark(DateTime _date, string _estimation)
            {
                date = _date;
                estimation = _estimation;
            }
        }

        public class Student
        {
            public int year { get; set; }
            public int group { get; set; }
            public string fio { get; set; }
            public Student()
            {
                year = 2000;
                group = 100;
                fio = "Иванов Иван Иванович";
            }
            public Student(int _year, int _group, string _fio)
            {
                year = _year;
                group = _group;
                fio = _fio;
            }
        }

        public double MinAVG(string[] marks)
        {
            double marksCount = 0;
            double marksSumma = 0;
            for (int i = 0; i < marks.Length; i++)
            {
                try
                {
                    marksSumma += Convert.ToInt32(marks[i]);
                    marksCount += 1;
                }
                catch
                {

                }
            }
            return Convert.ToDouble((marksSumma / marksCount).ToString().Substring(0, 3));
        }

        public int[] GetCountTruancy(List<Mark> marks)
        {
            List<int> date = new List<int> { };
            for (int i = 0; i < marks.Count; i++)
            {
                date.Add(marks[i].date.Month);
            }
            List<int> dateDistinct = date.Distinct().ToList();
            List<int> countTruancy = new List<int> { };
            int truancy = 0;
            for (int i = 0; i < dateDistinct.Count; i++)
            {
                truancy = 0;
                for (int j = 0; j < marks.Count; j++)
                {
                    if (marks[j].estimation.ToLower() == "прогул" && marks[j].date.Month == dateDistinct[i])
                    {
                        truancy += 1;
                    }
                }
                countTruancy.Add(truancy);
            }
            return countTruancy.ToArray();
        }

        public int[] GetCountDisease(List<Mark> marks)
        {
            List<int> date = new List<int> { };
            for (int i = 0; i < marks.Count; i++)
            {
                date.Add(marks[i].date.Month);
            }
            List<int> dateDistinct = date.Distinct().ToList();
            List<int> countDisease = new List<int> { };
            int disease = 0;
            for (int i = 0; i < dateDistinct.Count; i++)
            {
                disease = 0;
                for (int j = 0; j < marks.Count; j++)
                {
                    if (marks[j].estimation.ToLower() == "болезнь" && marks[j].date.Month == dateDistinct[i])
                    {
                        disease += 1;
                    }
                }
                countDisease.Add(disease);
            }
            return countDisease.ToArray();
        }

        public string GetStudNumber(Student student)
        {
            string[] words = student.fio.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            return student.year.ToString() + '.' + student.group.ToString() + '.' + words[0][0].ToString().ToLower() + words[1][0].ToString().ToLower() + words[2][0].ToString().ToLower();
        }

        public List<Mark> GetMarks(DateTime now, List<Student> students)
        {
            Random random = new Random();
            List<string> marksType = new List<string> { "1", "2", "3", "4", "5", "прогул", "болезнь", "отсутствие" };
            List<Mark> marks = new List<Mark> { };
            for (int i = 0; i < students.Count; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    Mark mark = new Mark(now.AddDays(j), marksType[random.Next(0, 7)]);
                    marks.Add(mark);
                }
            }
            return marks;
        }
    }
}
